# Interactive Feedback MCP UI
# Developed by Fábio Ferreira (https://x.com/fabiomlferreira)
# Inspired by/related to dotcursorrules.com (https://dotcursorrules.com/)
import os
import sys
import json
import psutil
import argparse
import subprocess
import threading
import hashlib
from typing import Optional, TypedDict

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QCheckBox, QTextEdit, QGroupBox, QDialog, QListWidget, QDialogButtonBox, QComboBox, QFileDialog
)
from PySide6.QtCore import Qt, Signal, QObject, QTimer, QSettings, QPoint
from PySide6.QtGui import QTextCursor, QIcon, QKeyEvent, QFont, QFontDatabase, QPalette, QColor

class FeedbackResult(TypedDict):
    command_logs: str
    interactive_feedback: str
    uploaded_images: list[str]

class FeedbackConfig(TypedDict):
    run_command: str
    execute_automatically: bool

def set_dark_title_bar(widget: QWidget, dark_title_bar: bool) -> None:
    # Ensure we're on Windows
    if sys.platform != "win32":
        return

    from ctypes import windll, c_uint32, byref

    # Get Windows build number
    build_number = sys.getwindowsversion().build
    if build_number < 17763:  # Windows 10 1809 minimum
        return

    # Check if the widget's property already matches the setting
    dark_prop = widget.property("DarkTitleBar")
    if dark_prop is not None and dark_prop == dark_title_bar:
        return

    # Set the property (True if dark_title_bar != 0, False otherwise)
    widget.setProperty("DarkTitleBar", dark_title_bar)

    # Load dwmapi.dll and call DwmSetWindowAttribute
    dwmapi = windll.dwmapi
    hwnd = widget.winId()  # Get the window handle
    attribute = 20 if build_number >= 18985 else 19  # Use newer attribute for newer builds
    c_dark_title_bar = c_uint32(dark_title_bar)  # Convert to C-compatible uint32
    dwmapi.DwmSetWindowAttribute(hwnd, attribute, byref(c_dark_title_bar), 4)

    # HACK: Create a 1x1 pixel frameless window to force redraw
    temp_widget = QWidget(None, Qt.FramelessWindowHint)
    temp_widget.resize(1, 1)
    temp_widget.move(widget.pos())
    temp_widget.show()
    temp_widget.deleteLater()  # Safe deletion in Qt event loop

def get_dark_mode_palette(app: QApplication):
    darkPalette = app.palette()
    
    # 现代化深灰色背景，更实用
    darkPalette.setColor(QPalette.Window, QColor(33, 37, 43))
    darkPalette.setColor(QPalette.WindowText, QColor(238, 238, 238))
    darkPalette.setColor(QPalette.Disabled, QPalette.WindowText, QColor(128, 128, 128))
    
    # 稍深的背景色
    darkPalette.setColor(QPalette.Base, QColor(24, 28, 34))
    darkPalette.setColor(QPalette.AlternateBase, QColor(44, 49, 57))
    darkPalette.setColor(QPalette.ToolTipBase, QColor(33, 37, 43))
    darkPalette.setColor(QPalette.ToolTipText, QColor(238, 238, 238))
    darkPalette.setColor(QPalette.Text, QColor(238, 238, 238))
    darkPalette.setColor(QPalette.Disabled, QPalette.Text, QColor(128, 128, 128))
    
    darkPalette.setColor(QPalette.Dark, QColor(20, 22, 27))
    darkPalette.setColor(QPalette.Shadow, QColor(15, 17, 21))
    
    # 按钮颜色
    darkPalette.setColor(QPalette.Button, QColor(57, 63, 76))
    darkPalette.setColor(QPalette.ButtonText, QColor(238, 238, 238))
    darkPalette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(128, 128, 128))
    
    darkPalette.setColor(QPalette.BrightText, QColor(255, 85, 85))
    
    # 高亮色使用蓝绿色调，更现代
    darkPalette.setColor(QPalette.Link, QColor(41, 182, 246))
    darkPalette.setColor(QPalette.Highlight, QColor(38, 166, 154))
    darkPalette.setColor(QPalette.Disabled, QPalette.Highlight, QColor(77, 85, 99))
    darkPalette.setColor(QPalette.HighlightedText, QColor(255, 255, 255))
    darkPalette.setColor(QPalette.Disabled, QPalette.HighlightedText, QColor(150, 150, 150))
    
    darkPalette.setColor(QPalette.PlaceholderText, QColor(150, 150, 150))
    
    return darkPalette

def kill_tree(process: subprocess.Popen):
    killed: list[psutil.Process] = []
    parent = psutil.Process(process.pid)
    for proc in parent.children(recursive=True):
        try:
            proc.kill()
            killed.append(proc)
        except psutil.Error:
            pass
    try:
        parent.kill()
    except psutil.Error:
        pass
    killed.append(parent)

    # Terminate any remaining processes
    for proc in killed:
        try:
            if proc.is_running():
                proc.terminate()
        except psutil.Error:
            pass

def get_user_environment() -> dict[str, str]:
    if sys.platform != "win32":
        return os.environ.copy()

    import ctypes
    from ctypes import wintypes

    # Load required DLLs
    advapi32 = ctypes.WinDLL("advapi32")
    userenv = ctypes.WinDLL("userenv")
    kernel32 = ctypes.WinDLL("kernel32")

    # Constants
    TOKEN_QUERY = 0x0008

    # Function prototypes
    OpenProcessToken = advapi32.OpenProcessToken
    OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    OpenProcessToken.restype = wintypes.BOOL

    CreateEnvironmentBlock = userenv.CreateEnvironmentBlock
    CreateEnvironmentBlock.argtypes = [ctypes.POINTER(ctypes.c_void_p), wintypes.HANDLE, wintypes.BOOL]
    CreateEnvironmentBlock.restype = wintypes.BOOL

    DestroyEnvironmentBlock = userenv.DestroyEnvironmentBlock
    DestroyEnvironmentBlock.argtypes = [wintypes.LPVOID]
    DestroyEnvironmentBlock.restype = wintypes.BOOL

    GetCurrentProcess = kernel32.GetCurrentProcess
    GetCurrentProcess.argtypes = []
    GetCurrentProcess.restype = wintypes.HANDLE

    CloseHandle = kernel32.CloseHandle
    CloseHandle.argtypes = [wintypes.HANDLE]
    CloseHandle.restype = wintypes.BOOL

    # Get process token
    token = wintypes.HANDLE()
    if not OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, ctypes.byref(token)):
        raise RuntimeError("Failed to open process token")

    try:
        # Create environment block
        environment = ctypes.c_void_p()
        if not CreateEnvironmentBlock(ctypes.byref(environment), token, False):
            raise RuntimeError("Failed to create environment block")

        try:
            # Convert environment block to list of strings
            result = {}
            env_ptr = ctypes.cast(environment, ctypes.POINTER(ctypes.c_wchar))
            offset = 0

            while True:
                # Get string at current offset
                current_string = ""
                while env_ptr[offset] != "\0":
                    current_string += env_ptr[offset]
                    offset += 1

                # Skip null terminator
                offset += 1

                # Break if we hit double null terminator
                if not current_string:
                    break

                equal_index = current_string.index("=")
                if equal_index == -1:
                    continue

                key = current_string[:equal_index]
                value = current_string[equal_index + 1:]
                result[key] = value

            return result

        finally:
            DestroyEnvironmentBlock(environment)

    finally:
        CloseHandle(token)

class FeedbackTextEdit(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptRichText(False)  # 禁用富文本粘贴，只允许纯文本

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Return and event.modifiers() == Qt.ControlModifier:
            # Find the parent FeedbackUI instance and call submit
            parent = self.parent()
            while parent and not isinstance(parent, FeedbackUI):
                parent = parent.parent()
            if parent:
                parent._submit_feedback()
        else:
            super().keyPressEvent(event)

class QuickReplyEditDialog(QDialog):
    """用于编辑快捷回复的对话框"""
    def __init__(self, parent=None, quick_replies=None):
        super().__init__(parent)
        self.setWindowTitle("编辑快捷回复")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)
        
        # 初始化快捷回复列表
        self.quick_replies = quick_replies or []
        
        # 创建UI
        layout = QVBoxLayout(self)
        
        # 添加说明标签
        label = QLabel("编辑、添加或删除快捷回复项目:")
        layout.addWidget(label)
        
        # 创建列表显示当前快捷回复
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QListWidget.SingleSelection)
        # 添加现有快捷回复到列表
        for reply in self.quick_replies:
            self.list_widget.addItem(reply)
        layout.addWidget(self.list_widget)
        
        # 编辑区域
        edit_layout = QHBoxLayout()
        self.edit_input = QLineEdit()
        self.edit_input.setPlaceholderText("输入新的快捷回复...")
        edit_layout.addWidget(self.edit_input)
        
        # 添加按钮
        self.add_button = QPushButton("添加")
        self.add_button.clicked.connect(self._add_reply)
        edit_layout.addWidget(self.add_button)
        
        layout.addLayout(edit_layout)
        
        # 操作按钮行
        button_layout = QHBoxLayout()
        
        # 删除按钮
        self.delete_button = QPushButton("删除所选")
        self.delete_button.clicked.connect(self._delete_reply)
        button_layout.addWidget(self.delete_button)
        
        # 上移按钮
        self.move_up_button = QPushButton("上移")
        self.move_up_button.clicked.connect(self._move_up)
        button_layout.addWidget(self.move_up_button)
        
        # 下移按钮
        self.move_down_button = QPushButton("下移")
        self.move_down_button.clicked.connect(self._move_down)
        button_layout.addWidget(self.move_down_button)
        
        layout.addLayout(button_layout)
        
        # 底部按钮行（确定/取消）
        dialog_buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        dialog_buttons.accepted.connect(self.accept)
        dialog_buttons.rejected.connect(self.reject)
        layout.addWidget(dialog_buttons)
        
        # 连接列表项被选中的信号
        self.list_widget.itemSelectionChanged.connect(self._selection_changed)
        self.list_widget.itemDoubleClicked.connect(self._edit_item)
        
        # 初始化按钮状态
        self._selection_changed()
    
    def _add_reply(self):
        """添加新的快捷回复"""
        text = self.edit_input.text().strip()
        if text:
            self.list_widget.addItem(text)
            self.edit_input.clear()
    
    def _delete_reply(self):
        """删除选中的快捷回复"""
        selected_items = self.list_widget.selectedItems()
        if selected_items:
            for item in selected_items:
                row = self.list_widget.row(item)
                self.list_widget.takeItem(row)
    
    def _move_up(self):
        """上移选中的项目"""
        selected_items = self.list_widget.selectedItems()
        if not selected_items:
            return
            
        current_row = self.list_widget.row(selected_items[0])
        if current_row > 0:
            item = self.list_widget.takeItem(current_row)
            self.list_widget.insertItem(current_row - 1, item)
            self.list_widget.setCurrentItem(item)
    
    def _move_down(self):
        """下移选中的项目"""
        selected_items = self.list_widget.selectedItems()
        if not selected_items:
            return
            
        current_row = self.list_widget.row(selected_items[0])
        if current_row < self.list_widget.count() - 1:
            item = self.list_widget.takeItem(current_row)
            self.list_widget.insertItem(current_row + 1, item)
            self.list_widget.setCurrentItem(item)
    
    def _selection_changed(self):
        """当列表选择变化时更新按钮状态"""
        has_selection = bool(self.list_widget.selectedItems())
        self.delete_button.setEnabled(has_selection)
        self.move_up_button.setEnabled(has_selection and self.list_widget.currentRow() > 0)
        self.move_down_button.setEnabled(has_selection and self.list_widget.currentRow() < self.list_widget.count() - 1)
    
    def _edit_item(self, item):
        """双击编辑项目"""
        self.edit_input.setText(item.text())
        self.list_widget.takeItem(self.list_widget.row(item))
    
    def get_quick_replies(self):
        """获取编辑后的快捷回复列表"""
        result = []
        for i in range(self.list_widget.count()):
            result.append(self.list_widget.item(i).text())
        return result

class LogSignals(QObject):
    append_log = Signal(str)

class FeedbackUI(QMainWindow):
    def __init__(self, project_directory: str, prompt: str):
        super().__init__()
        self.project_directory = project_directory
        self.prompt = prompt

        self.process: Optional[subprocess.Popen] = None
        self.log_buffer = []
        self.feedback_result = None
        self.log_signals = LogSignals()
        self.log_signals.append_log.connect(self._append_log)
        
        # 初始化上传图片路径列表
        self.uploaded_images = []

        # 窗口大小设置
        self.default_size = (460, 360)
        self.size_multiplier = 1
        self.size_states = [1, 2, 3]  # 窗口大小倍数状态

        self.setWindowTitle("交互式反馈 MCP")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        icon_path = os.path.join(script_dir, "images", "feedback.png")
        self.setWindowIcon(QIcon(icon_path))
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        
        # 设置默认窗口大小
        self.resize(*self.default_size)
        
        self.settings = QSettings("InteractiveFeedbackMCP", "InteractiveFeedbackMCP")
        
        # Load general UI settings for the main window (geometry, state)
        self.settings.beginGroup("MainWindow_General")
        geometry = self.settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        else:
            # 设置窗口位置在屏幕右下角
            self._position_window_bottom_right()
        state = self.settings.value("windowState")
        if state:
            self.restoreState(state)
            
        # 检查是否有用户保存的自定义位置
        self.use_custom_position = self.settings.value("use_custom_position", False, type=bool)
        custom_x = self.settings.value("custom_position_x", -1, type=int)
        custom_y = self.settings.value("custom_position_y", -1, type=int)
        self.custom_position = None
        if custom_x >= 0 and custom_y >= 0:
            from PySide6.QtCore import QPoint
            self.custom_position = QPoint(custom_x, custom_y)
            
        # 加载快捷回复设置
        self.quick_replies = self.settings.value("quick_replies", [], type=list)
        # 如果没有保存的快捷回复，使用默认值
        if not self.quick_replies:
            self.quick_replies = ["继续", "结束对话","使用MODE: RESEARCH重新开始"]
        self.settings.endGroup() # End "MainWindow_General" group
        
        # Load project-specific settings (command, auto-execute, command section visibility)
        self.project_group_name = get_project_settings_group(self.project_directory)
        self.settings.beginGroup(self.project_group_name)
        loaded_run_command = self.settings.value("run_command", "", type=str)
        loaded_execute_auto = self.settings.value("execute_automatically", False, type=bool)
        command_section_visible = self.settings.value("commandSectionVisible", False, type=bool)
        self.settings.endGroup() # End project-specific group
        
        self.config: FeedbackConfig = {
            "run_command": loaded_run_command,
            "execute_automatically": loaded_execute_auto
        }

        self._create_ui() # self.config is used here to set initial values

        # Set command section visibility AFTER _create_ui has created relevant widgets
        self.command_group.setVisible(command_section_visible)
        if command_section_visible:
            self.toggle_command_button.setText("隐藏终端")
        else:
            self.toggle_command_button.setText("显示终端")

        # set_dark_title_bar(self, True)
        
        # 确保窗口位于正确位置
        QTimer.singleShot(0, self._position_window_bottom_right)

        if self.config.get("execute_automatically", False):
            self._run_command()

    def _position_window_bottom_right(self):
        """将窗口定位在屏幕右下角或用户自定义位置"""
        # 如果有用户保存的自定义位置，优先使用
        if hasattr(self, 'use_custom_position') and self.use_custom_position and self.custom_position:
            self.move(self.custom_position)
            return
            
        # 否则使用默认的右下角位置
        current_width = self.width()
        current_height = self.height()
        screen_geometry = QApplication.primaryScreen().availableGeometry()
        x = screen_geometry.width() - current_width - 20  # 右边距20像素
        y = screen_geometry.height() - current_height - 40  # 下边距40像素
        self.move(x, y)

    def _format_windows_path(self, path: str) -> str:
        if sys.platform == "win32":
            # Convert forward slashes to backslashes
            path = path.replace("/", "\\")
            # Capitalize drive letter if path starts with x:\
            if len(path) >= 2 and path[1] == ":" and path[0].isalpha():
                path = path[0].upper() + path[1:]
        return path

    def _create_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # 顶部按钮行
        top_buttons_layout = QHBoxLayout()
        
        # 终端显示/隐藏按钮
        self.toggle_command_button = QPushButton("显示终端")
        self.toggle_command_button.clicked.connect(self._toggle_command_section)
        self.toggle_command_button.setMinimumWidth(120)
        self.toggle_command_button.setMinimumHeight(30)
        top_buttons_layout.addWidget(self.toggle_command_button)
        
        # 窗口大小调整按钮
        self.resize_button = QPushButton("调整窗口大小")
        self.resize_button.clicked.connect(self._cycle_window_size)
        self.resize_button.setMinimumWidth(120)
        self.resize_button.setMinimumHeight(30)
        top_buttons_layout.addWidget(self.resize_button)
        
        # 保存窗口位置按钮
        self.save_position_button = QPushButton("保存窗口位置")
        self.save_position_button.clicked.connect(self._save_window_position)
        self.save_position_button.setMinimumWidth(120)
        self.save_position_button.setMinimumHeight(30)
        top_buttons_layout.addWidget(self.save_position_button)
        
        layout.addLayout(top_buttons_layout)

        # Command section
        self.command_group = QGroupBox("终端")
        command_layout = QVBoxLayout(self.command_group)

        # Working directory label
        formatted_path = self._format_windows_path(self.project_directory)
        working_dir_label = QLabel(f"工作目录: {formatted_path}")
        command_layout.addWidget(working_dir_label)

        # Command input row
        command_input_layout = QHBoxLayout()
        self.command_entry = QLineEdit()
        self.command_entry.setText(self.config["run_command"])
        self.command_entry.returnPressed.connect(self._run_command)
        self.command_entry.textChanged.connect(self._update_config)
        self.run_button = QPushButton("运行(&R)")
        self.run_button.clicked.connect(self._run_command)
        self.run_button.setMinimumWidth(80)
        self.run_button.setMinimumHeight(30)

        command_input_layout.addWidget(self.command_entry)
        command_input_layout.addWidget(self.run_button)
        command_layout.addLayout(command_input_layout)

        # Auto-execute and save config row
        auto_layout = QHBoxLayout()
        self.auto_check = QCheckBox("下次自动执行（打开此应用时自动运行命令）")
        self.auto_check.setChecked(self.config.get("execute_automatically", False))
        self.auto_check.stateChanged.connect(self._update_config)

        save_button = QPushButton("保存命令(&S)")
        save_button.clicked.connect(self._save_config)
        save_button.setMinimumWidth(100)
        save_button.setMinimumHeight(30)

        auto_layout.addWidget(self.auto_check)
        auto_layout.addStretch()
        auto_layout.addWidget(save_button)
        command_layout.addLayout(auto_layout)

        # Console section (now part of command_group)
        console_group = QGroupBox("控制台")
        console_layout_internal = QVBoxLayout(console_group)
        console_group.setMinimumHeight(200)

        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(False)  # 设置为可编辑
        font = QFont(QFontDatabase.systemFont(QFontDatabase.FixedFont))
        font.setPointSize(9)
        self.log_text.setFont(font)
        console_layout_internal.addWidget(self.log_text)

        # Control buttons
        button_layout = QHBoxLayout()
        self.clear_button = QPushButton("清除(&C)")
        self.clear_button.clicked.connect(self.clear_logs)
        self.clear_button.setMinimumWidth(80)
        self.clear_button.setMinimumHeight(30)
        
        button_layout.addStretch()
        button_layout.addWidget(self.clear_button)
        console_layout_internal.addLayout(button_layout)
        
        command_layout.addWidget(console_group)

        self.command_group.setVisible(False) 
        layout.addWidget(self.command_group)

        # Feedback section with adjusted height
        self.feedback_group = QGroupBox("反馈")
        feedback_layout = QVBoxLayout(self.feedback_group)

        # Short description label (from self.prompt)
        self.description_label = QLabel(self.prompt)
        self.description_label.setWordWrap(True)
        feedback_layout.addWidget(self.description_label)

        self.feedback_text = FeedbackTextEdit()
        font_metrics = self.feedback_text.fontMetrics()
        row_height = font_metrics.height()
        # Calculate height for 5 lines + some padding for margins
        padding = self.feedback_text.contentsMargins().top() + self.feedback_text.contentsMargins().bottom() + 5 # 5 is extra vertical padding
        self.feedback_text.setMinimumHeight(5 * row_height + padding)

        self.feedback_text.setPlaceholderText("在此输入您的反馈 (按Ctrl+Enter提交)")
        
        # 根据系统类型设置快捷键提示
        if sys.platform == "darwin":  # macOS
            submit_button_text = "发送反馈(&S) (Cmd+Enter)"
            shortcut_text = "Cmd+Enter"
        else:  # Windows, Linux等其他系统
            submit_button_text = "发送反馈(&S) (Ctrl+Enter)"
            shortcut_text = "Ctrl+Enter"
        
        # 更新占位符文本
        self.feedback_text.setPlaceholderText(f"在此输入您的反馈 (按{shortcut_text}提交)")
        
        submit_button = QPushButton(submit_button_text)
        
        submit_button.clicked.connect(self._submit_feedback)
        submit_button.setMinimumWidth(200)
        submit_button.setMinimumHeight(60)

        feedback_layout.addWidget(self.feedback_text)
        
        # 添加快捷回复控件
        quick_reply_layout = QHBoxLayout()
        
        # 开始实施按钮 - 放在最左侧
        start_button = QPushButton("开始实施")
        start_button.clicked.connect(lambda: self._insert_quick_reply("开始实施"))
        start_button.setMinimumHeight(30)
        quick_reply_layout.addWidget(start_button)
        
        # 快捷回复组合框 - 放在中间
        self.quick_reply_combo = QComboBox()
        self.quick_reply_combo.setMinimumHeight(30)
        self.quick_reply_combo.setMinimumWidth(180)
        # 添加快捷回复选项
        for reply in self.quick_replies:
            self.quick_reply_combo.addItem(reply)
        # 连接信号：当选择变更时自动填入文本框
        self.quick_reply_combo.activated.connect(self._apply_selected_quick_reply)
        quick_reply_layout.addWidget(self.quick_reply_combo)
        
        # 编辑快捷回复按钮 - 放在最右侧
        edit_replies_button = QPushButton("编辑快捷回复")
        edit_replies_button.clicked.connect(self._edit_quick_replies)
        edit_replies_button.setMinimumHeight(30)
        quick_reply_layout.addWidget(edit_replies_button)
        
        # 上传图片按钮 - 放在编辑快捷回复按钮右侧
        upload_image_button = QPushButton("上传图片")
        upload_image_button.clicked.connect(self._upload_image)
        upload_image_button.setMinimumHeight(30)
        quick_reply_layout.addWidget(upload_image_button)
        
        feedback_layout.addLayout(quick_reply_layout)
        feedback_layout.addWidget(submit_button)

        # Set minimum height for feedback_group to accommodate its contents
        # This will be based on the description label, the 5-line feedback_text, quick reply buttons and submit button
        self.feedback_group.setMinimumHeight(self.description_label.sizeHint().height() + 
                                            self.feedback_text.minimumHeight() + 
                                            start_button.sizeHint().height() + 
                                            edit_replies_button.sizeHint().height() + 
                                            upload_image_button.sizeHint().height() + 
                                            submit_button.sizeHint().height() + 30) # 增加额外间距

        # Add widgets in a specific order
        layout.addWidget(self.feedback_group)

    def _cycle_window_size(self):
        """循环调整窗口大小：默认 -> x2 -> x3 -> 默认"""
        # 获取当前倍数索引
        current_index = self.size_states.index(self.size_multiplier)
        # 计算下一个倍数索引（循环）
        next_index = (current_index + 1) % len(self.size_states)
        # 设置新的倍数
        self.size_multiplier = self.size_states[next_index]
        
        # 计算新的窗口大小
        new_width = self.default_size[0] * self.size_multiplier
        new_height = self.default_size[1] * self.size_multiplier
        
        # 调整窗口大小
        self.resize(new_width, new_height)
        
        # 如果使用自定义位置，保持当前位置
        if hasattr(self, 'use_custom_position') and self.use_custom_position and self.custom_position:
            # 不移动窗口，保持当前位置
            pass
        else:
            # 重新计算窗口位置，保持在屏幕右下角
            screen_geometry = QApplication.primaryScreen().availableGeometry()
            x = screen_geometry.width() - new_width - 20  # 右边距20像素
            y = screen_geometry.height() - new_height - 40  # 下边距40像素
            self.move(x, y)
        
        # 更新按钮文本
        if self.size_multiplier == 1:
            self.resize_button.setText("调整窗口大小")
        else:
            self.resize_button.setText(f"窗口大小 x{self.size_multiplier}")

    def _toggle_command_section(self):
        is_visible = self.command_group.isVisible()
        self.command_group.setVisible(not is_visible)
        if not is_visible:
            self.toggle_command_button.setText("隐藏终端")
        else:
            self.toggle_command_button.setText("显示终端")
        
        # Immediately save the visibility state for this project
        self.settings.beginGroup(self.project_group_name)
        self.settings.setValue("commandSectionVisible", self.command_group.isVisible())
        self.settings.endGroup()

        # Adjust window height only
        new_height = self.centralWidget().sizeHint().height()
        if self.command_group.isVisible() and self.command_group.layout().sizeHint().height() > 0 :
             # if command group became visible and has content, ensure enough height
             min_content_height = self.command_group.layout().sizeHint().height() + self.feedback_group.minimumHeight() + self.toggle_command_button.height() + 20  # 使用固定间距值替代layout().spacing()
             new_height = max(new_height, min_content_height)

        current_width = self.width()
        self.resize(current_width, new_height)

    def _update_config(self):
        self.config["run_command"] = self.command_entry.text()
        self.config["execute_automatically"] = self.auto_check.isChecked()

    def _append_log(self, text: str):
        self.log_buffer.append(text)
        self.log_text.append(text.rstrip())
        cursor = self.log_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.log_text.setTextCursor(cursor)

    def _check_process_status(self):
        if self.process and self.process.poll() is not None:
            # Process has terminated
            exit_code = self.process.poll()
            self._append_log(f"\n进程已退出，退出代码 {exit_code}\n")
            self.run_button.setText("运行(&R)")
            self.process = None
            self.activateWindow()
            self.feedback_text.setFocus()

    def _run_command(self):
        if self.process:
            kill_tree(self.process)
            self.process = None
            self.run_button.setText("运行(&R)")
            return

        # Clear the log buffer but keep UI logs visible
        self.log_buffer = []

        command = self.command_entry.text()
        if not command:
            return

        self._append_log(f"$ {command}\n")
        self.run_button.setText("停止(&p)")

        try:
            self.process = subprocess.Popen(
                command,
                shell=True,
                cwd=self.project_directory,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=get_user_environment(),
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="ignore",
                close_fds=True,
            )

            def read_output(pipe):
                for line in iter(pipe.readline, ""):
                    self.log_signals.append_log.emit(line)

            threading.Thread(
                target=read_output,
                args=(self.process.stdout,),
                daemon=True
            ).start()

            threading.Thread(
                target=read_output,
                args=(self.process.stderr,),
                daemon=True
            ).start()

            # Start process status checking
            self.status_timer = QTimer()
            self.status_timer.timeout.connect(self._check_process_status)
            self.status_timer.start(100)  # Check every 100ms

        except Exception as e:
            self._append_log(f"运行命令时出错: {str(e)}\n")
            self.run_button.setText("运行(&R)")

    def _submit_feedback(self):
        # 如果是空的话修改为 Continue 提交
        # if self.feedback_text.toPlainText().strip() == "":
        #     self.feedback_text.setText("Continue")
        # self.feedback_result = FeedbackResult(
        #     logs="".join(self.log_buffer),
        #     interactive_feedback=self.feedback_text.toPlainText().strip(),
        #     uploaded_images=self.uploaded_images
        # )
        self.feedback_result = {
            "logs": "".join(self.log_buffer),
            "interactive_feedback": self.feedback_text.toPlainText().strip(),
            "uploaded_images": self.uploaded_images
        }
        
        self.close()
        
    def _insert_quick_reply(self, text: str):
        """将预设文本插入到反馈文本框中"""
        self.feedback_text.setText(text)
        self.feedback_text.setFocus()
        # 如果是 开始实施 的话，直接发送反馈
        if text == "开始实施":
            self._submit_feedback()
        
    def _apply_selected_quick_reply(self):
        """应用当前在组合框中选择的快捷回复"""
        selected_text = self.quick_reply_combo.currentText()
        if selected_text:
            self._insert_quick_reply(selected_text)
            
    def _edit_quick_replies(self):
        """打开编辑快捷回复对话框"""
        dialog = QuickReplyEditDialog(self, self.quick_replies)
        if dialog.exec():
            # 用户点击了确定，保存编辑后的快捷回复
            self.quick_replies = dialog.get_quick_replies()
            
            # 更新组合框内容
            self.quick_reply_combo.clear()
            for reply in self.quick_replies:
                self.quick_reply_combo.addItem(reply)
                
            # 保存到设置
            self.settings.beginGroup("MainWindow_General")
            self.settings.setValue("quick_replies", self.quick_replies)
            self.settings.endGroup()
           
    def _upload_image(self):
        """上传图片"""
        # 打开文件选择对话框，限制为图片文件
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择图片",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.gif *.bmp)"
        )
        if file_path:
            self.uploaded_images.append(file_path)
            
            
        
    def clear_logs(self):
        self.log_buffer = []
        self.log_text.clear()
        
    def _save_config(self):
        # Save run_command and execute_automatically to QSettings under project group
        self.settings.beginGroup(self.project_group_name)
        self.settings.setValue("run_command", self.config["run_command"])
        self.settings.setValue("execute_automatically", self.config["execute_automatically"])
        self.settings.endGroup()
        
    def _save_window_position(self):
        """保存当前窗口位置到用户设置"""
        # 保存窗口位置到通用设置组
        pos = self.pos()
        self.settings.beginGroup("MainWindow_General")
        self.settings.setValue("custom_position_x", pos.x())
        self.settings.setValue("custom_position_y", pos.y())
        self.settings.setValue("use_custom_position", True)
        self.settings.endGroup()
        
        # 提示用户已保存位置
        status_message = f"已保存窗口位置 ({pos.x()}, {pos.y()})"
        
        # 如果命令控制台不可见，显示临时状态消息
        if not self.command_group.isVisible():
            # 创建一个临时标签显示在窗口底部
            from PySide6.QtWidgets import QLabel
            from PySide6.QtCore import QTimer
            
            status_label = QLabel(status_message, self)
            status_label.setStyleSheet("background-color: rgba(0, 0, 0, 0.7); color: white; padding: 5px; border-radius: 3px;")
            status_label.adjustSize()
            
            # 放置在窗口底部中央
            label_x = (self.width() - status_label.width()) // 2
            label_y = self.height() - status_label.height() - 10
            status_label.move(label_x, label_y)
            status_label.show()
            
            # 3秒后自动隐藏
            QTimer.singleShot(3000, status_label.deleteLater)

    def closeEvent(self, event):
        # Save general UI settings for the main window (geometry, state)
        self.settings.beginGroup("MainWindow_General")
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        self.settings.endGroup()

        # Save project-specific command section visibility (this is now slightly redundant due to immediate save in toggle, but harmless)
        self.settings.beginGroup(self.project_group_name)
        self.settings.setValue("commandSectionVisible", self.command_group.isVisible())
        self.settings.endGroup()

        # 自动保存配置，确保"下次自动执行"选项等设置被保存
        self._save_config()

        if self.process:
            kill_tree(self.process)
            
        super().closeEvent(event)

    def run(self) -> FeedbackResult:
        self.show()
        QApplication.instance().exec()

        if self.process:
            kill_tree(self.process)

        if not self.feedback_result:
            return FeedbackResult(
                logs="".join(self.log_buffer), 
                interactive_feedback="",
                uploaded_images=[]
            )

        return self.feedback_result

def get_project_settings_group(project_dir: str) -> str:
    # Create a safe, unique group name from the project directory path
    # Using only the last component + hash of full path to keep it somewhat readable but unique
    basename = os.path.basename(os.path.normpath(project_dir))
    full_hash = hashlib.md5(project_dir.encode('utf-8')).hexdigest()[:8]
    return f"{basename}_{full_hash}"

def feedback_ui(project_directory: str, prompt: str, output_file: Optional[str] = None) -> Optional[FeedbackResult]:
    app = QApplication.instance() or QApplication()
    
    # 在提示文本中添加AI助手信息
    ai_prompt = f"AI助手: {prompt}"
    
    ui = FeedbackUI(project_directory, ai_prompt)
    result = ui.run()

    if output_file and result:
        # Ensure the directory exists
        os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else ".", exist_ok=True)
        # Save the result to the output file
        with open(output_file, "w") as f:
            json.dump(result, f)
        return None

    return result

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="运行反馈用户界面")
    parser.add_argument("--project-directory", default=os.getcwd(), help="The project directory to run the command in")
    parser.add_argument("--prompt", default="I implemented the changes you requested.", help="The prompt to show to the user")
    parser.add_argument("--output-file", help="Path to save the feedback result as JSON")
    args = parser.parse_args()

    result = feedback_ui(args.project_directory, args.prompt, args.output_file)
    if result:
        # 只在有日志内容时输出日志部分
        # if result['logs'].strip():
        #     print(f"\nLogs collected: \n{result['logs']}")
        #
        # print(f"\nFeedback received:\n{result['interactive_feedback']}")
        # // UI返回给server.py的原始JSON结构示例
# {
#   "content": [
#     {"type": "text", "text": "用户的文本反馈..."},
#     {"type": "image", "data": "base64_encoded_image_data", "mimeType": "image/jpeg"},
#     {"type": "file_reference", "display_name": "@example.txt", "path": "/path/to/local/example.txt"}
#     // ... 可能有更多项
#   ]
# }
        json_result = {
            "content": [
                {"type": "text", "text": "Logs collected: " + result['logs']},
                {"type": "text", "text": "Feedback received: " + result['interactive_feedback']},
            ]
        }
        import base64
        for image in result['uploaded_images']:
            imagebase64 = base64.b64encode(open(image, "rb").read()).decode("utf-8")
            json_result['content'].append({"type": "image", "data": imagebase64, "mimeType": "image/jpeg"})
        
        
        print(json.dumps(json_result, indent=4))
    sys.exit(0)
